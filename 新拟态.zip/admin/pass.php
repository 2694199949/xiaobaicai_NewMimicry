<?php 
/*
 版权所有：小白菜 QQ：2694199949
 开源地址：https://github.com/2694199949/xiaobaicai_NewMimicry
*/
$用户名='xiaobaicai'; $密码='123456';
?>