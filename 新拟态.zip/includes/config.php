<?php 
/*
 版权所有：小白菜 QQ：2694199949
 开源地址：https://github.com/2694199949/xiaobaicai_NewMimicry
*/
$config['title']='小白菜引导页';
$config['description']='新拟态个人主页';
$config['keywords']='个人主页,新拟态主页,白菜新拟态主页';
$config['sketch']='新拟态个人主页前端小白菜基于HTML与CSS开发';
$config['adminpng']='/assets/img/logo.png';
$config['adminname']='小白菜';
$config['hometitle']='New Mimicry';
$config['zuobiao']='中国 · 广东';
$config['guad']='CHINA GUANGDONG';
$config['fontqq']='待续';
$config['fontzfb']='待续';
$config['fontgithub']='待续';
$config['fontvx']='待续';
$config['zbox']='待续';
$config['webbox']='基于HTML+CSS开发<hr>呼呼啦啦的';
$config['footweb']='<font><a href="http://" target="_blank"><i></i>站点一</a></font>
      <font><a href="http://" target="_blank"><i></i>站点二</a></font>
      <font>
        <a href="http://" target="_blank"><i></i>站点三</a></font>';
$config['foot']='Copyright © 2021 版权所有.小白菜.<br>
项目开源地址：<a href="https://github.com/2694199949/xiaobaicai_NewMimicry" target="_blank">Github</a>.';
?>